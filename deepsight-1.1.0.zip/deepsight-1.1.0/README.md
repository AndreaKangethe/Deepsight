# DEEPSIGHT — See beyond the surface.

**MACHINE LEARNING-DRIVEN ATTACK SURFACE INTELLIGENCE AND VULNERABILITY MANAGEMENT PLATFORM** · version 1.1.0

DEEPSIGHT collects infrastructure observations from many sources, resolves asset identity with evidence, keeps history,
correlates vulnerabilities and CISA KEV, detects anomalous change with ML, scores contextual risk, tracks remediation, and
lets an analyst investigate with an evidence-grounded assistant. It is a prototype: [docs/IMPLEMENTATION_STATUS.md](docs/IMPLEMENTATION_STATUS.md)
separates what is implemented from the roadmap, and [docs/QA.md](docs/QA.md) lists the commands and measured results.

**Naming.** The product is DEEPSIGHT everywhere a person reads it. “ASIVM” (*Attack Surface Intelligence and Vulnerability
Management*) survives only as a compatibility prefix: `ASIVM_*` environment variables, the `asivm` database/user names in
Docker Compose and the `asivm.*` logger names.

**How to read the interface.** Every finding and risk shows its basis: *observed* (a source reported it), *inferred*
(DEEPSIGHT derived it), *ML-predicted*, or *analyst-validated*. An anomaly warrants review; it is not proof of malice.
Contextual risk is DEEPSIGHT's own explainable weighted score and is shown beside, not instead of, the published CVSS score.
No ML output is presented as confirmed.

## Quick start (Docker)
```bash
cp .env.example .env              # optional; edit values
docker compose up --build -d
docker compose logs app | grep -A4 "first start"   # the generated administrator password is printed once
```
Open http://localhost:8000 (API docs at `/api/docs` work offline; the Swagger UI is bundled in `app/static/vendor/`).
With `ASIVM_SEED_DEMO=true` (the Compose default) a **synthetic demo dataset** loads on first start: 14 days of history,
about 40 assets (8 of them IoT) and 11 sources. Set `ASIVM_SEED_DEMO=false` for an empty platform.

## One-command demo
```bash
python scripts/demo.py
```
Starts the stack plus the isolated IoT lab, waits for `/api/health`, imports the lab inventory, live-scans the four lab
devices and prints the URL. The administrator password comes from `ASIVM_ADMIN_PASSWORD` in the environment, or a hidden
prompt; no script accepts a password on the command line. Requires Docker.
Tear down: `docker compose -f docker-compose.yml -f docker-compose.lab.yml down`.

## Demo walkthrough
1. **Overview** — risk distribution, published CVSS vs contextual risk, and the freshness line (assets not recently assessed,
   assets with conflicting evidence). In the demo data, scanner CSV imports cannot declare a *complete* assessment, so assets
   read “not recently assessed” rather than “no vulnerability detected”; Trivy/Grype imports do declare scope.
2. **Administration › System › Apply drift scenario** — new exposed Tomcat AJP service on `app-server-01`, SMBv1 on `files-01`,
   a rogue device, Telnet on `camera-iot-01` and a port-forwarded MQTT broker on `temp-gw-01`. Overview then shows a critical
   contextual risk, **Intelligence › Anomalies** shows the ML flag.
3. **Work queue** — findings ordered by active work, overdue, KEV, contextual score, each with “why this needs attention”.
   Save a filter, select findings and triage them in bulk.
4. **Findings › a finding** — owner, due date, ticket link, accepted-risk/false-positive (reason, approver, expiry), the
   *what-if* risk reduction, and *Verify and close* (needs a newer successful scan observation that covers the finding).
5. **Assistant** — *“Why has the risk of app-server-01 increased?”*, *“What is connected to ci-server-01?”*,
   *“What changed in the last 24 hours?”*. Answers cite stored evidence.
6. **Intelligence › Identity** — a *probable* match (`ws-006`) awaits analyst confirmation; decisions are reversible.
7. **Coverage** — CMDB reconciliation (in CMDB but never seen, seen but not in CMDB, no owner) and candidate attack paths.
8. **Effectiveness** — *Run fixed evaluation* records identity and anomaly metrics on the fixed fixtures.
9. **Overview › Reset demo** (administrator) clears inventory, findings, investigations and integrations and reloads the demo.

**IoT**: Assets › filter type `iot_device`. Besides CVE matches, DEEPSIGHT scores exposed management interfaces,
end-of-life firmware, Telnet, FTP, cleartext MQTT, RTSP without authentication, raw print and Winbox as findings of their own
(`DS-IOT-*`), each with its risk factors and the source evidence.

## IoT lab (Docker, live scan)
Four throwaway devices on an isolated network, no host ports published: a Telnet device, a camera (web admin with default
credentials and RTSP), an SSH gateway (old Dropbear banner) and a real Mosquitto broker (anonymous, no TLS). The first three are
emulators (`lab/iot-sim/sim.py`): banners and fake login pages only; nothing executes and no credential is accepted.
```bash
docker compose -f docker-compose.yml -f docker-compose.lab.yml up --build -d
ASIVM_ADMIN_PASSWORD='<administrator password>' python lab/scan_lab.py      # or omit the variable to be prompted
docker compose -f docker-compose.yml -f docker-compose.lab.yml down
```
`lab/scan_lab.py` imports `lab/lab_inventory.json` and starts a TCP-connect scan of 172.28.50.10-13. The scan reads banners on
a few ports only, so firmware and vendor data come from the inventory file, as a passive IoT-discovery tool would report it.
Only scan targets you are authorised to scan; `ASIVM_TCP_ALLOWED_CIDRS` limits what the TCP connector may reach.

## Run without Docker
```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt            # add requirements-dev.txt for tests and linters
ASIVM_SEED_DEMO=true python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```
SQLite data and the generated secret key live in `./data`. The first start prints the administrator password. Run a **single**
app replica: identity resolution is serialised in-process.

## Checks
```bash
pip install -r requirements-dev.txt
python -m pytest tests -q
node --check app/static/app.js
python -m compileall -q app lab scripts
ruff check app lab scripts tests
pip-audit -r requirements.txt            # currently reports PyJWT 2.12.1 advisories; see docs/QA.md
```
Tests use their own temporary SQLite database. To run them on PostgreSQL set `ASIVM_TEST_DATABASE_URL` to a **new, empty,
disposable** database (re-using one from an earlier run makes tests fail on leftover rows); never point it at application data.

## Operations
- **Health**: `GET /api/health` (database, scheduler and worker heartbeats, last collection, queued jobs); 503 when degraded.
- **Metrics**: `GET /api/metrics` (Prometheus text; requires sign-in). **Logs** are JSON lines on stdout.
- **Jobs**: collections, maintenance, webhook delivery and KEV sync run through a durable queue (`GET /api/jobs`, administrator).
- **Retention**: raw observation payloads older than `ASIVM_RAW_RETENTION_DAYS` are moved to hash-named gzip files under
  `data/archive`; normalised history is kept.
- **Backup / restore** (the database URL comes from the environment, never from arguments):
  ```bash
  python scripts/backup.py backup backup.json         # writes backup.json and backup.json.sha256 (mode 0600)
  python scripts/backup.py check backup.json          # restore into a temporary SQLite database and compare every table
  ASIVM_RESTORE_DATABASE_URL=<new empty database> ASIVM_RESTORE_DATA_DIR=<empty dir> python scripts/backup.py restore backup.json
  ```
  The backup file contains password hashes and the deployment secret key and is not encrypted: store it like a secret.
- **Load test** (isolated temporary SQLite database): `python scripts/load_test.py --assets 1000` and `--assets 5001`.
- **Evaluation**: `python scripts/measure_evaluation.py` (also *Effectiveness › Run fixed evaluation*).
- **Protected-scope check**: `python scripts/check_scope.py <1.0.2 archive.zip>` compares the sign-in, session, token, role and
  access-control code with the original 1.0.2 archive. The archive is not part of this repository.

## Real data
Integrations → import vendor exports (nmap XML, CSV inventory, `aws ec2 describe-instances`, `az vm list -d`, OCI,
`kubectl get nodes,pods -o json`, scanner CSV/JSON, Trivy JSON, Grype JSON; examples in `samples/`), add an HTTP JSON collector or
authorised TCP discovery on a schedule, or `POST /api/observations`. Credentials are encrypted at rest and never returned.
To have a source counted as the CMDB in *Coverage*, create it with `category: "cmdb"` (or `config.is_cmdb: true`) through
`POST /api/integrations`. Outbound webhooks (new critical or KEV findings) are an integration of kind `outbound_webhook`.

## Configuration (environment)
| Variable | Meaning |
|---|---|
| `ASIVM_ADMIN_USER`, `ASIVM_ADMIN_PASSWORD` | initial administrator (empty password → generated and printed once) |
| `ASIVM_SECRET_KEY` | signs sessions and encrypts integration secrets; generated and kept in `data/` if empty |
| `ASIVM_DATABASE_URL`, `ASIVM_DATA_DIR` | database and data directory |
| `ASIVM_SEED_DEMO` | load the synthetic demo dataset on first start |
| `ASIVM_ASSESSMENT_AGE_HOURS` | how old a successful assessment may be before an asset reads “not recently assessed” (default 168) |
| `ASIVM_RAW_RETENTION_DAYS` | hot retention of raw payloads before archiving (default 30) |
| `ASIVM_WORKER`, `ASIVM_SCHEDULER` | run the durable job worker / the schedule loop in the app process |
| `ASIVM_TCP_ALLOWED_CIDRS`, `ASIVM_ALLOW_TCP_DISCOVERY` | where TCP discovery may connect, and whether it is enabled |
| `ASIVM_ANOMALY_THRESHOLD`, `ASIVM_INACTIVE_AFTER_HOURS` | anomaly cut-off (default derived from the model) and lifecycle sweep |
| `ASIVM_KEV_AUTO_SYNC` | daily CISA KEV sync (needs internet) |
| `ANTHROPIC_API_KEY`, `ASIVM_ASSISTANT_MODEL` | optional LLM mode for the assistant, still limited to platform evidence |
| `ASIVM_RATE_LIMIT_PER_MIN`, `ASIVM_LOGIN_RATE_LIMIT_PER_MIN`, `ASIVM_TOKEN_TTL_MINUTES` | rate limits and session lifetime |

## Layout
`app/` api.py · main.py · pipeline.py · collector.py · jobs.py · freshness.py · remediation.py · workqueue.py · evaluation.py ·
coverage.py · notifications.py · retention.py · migrations.py · observability.py · demo.py · services.py · assistant.py ·
connectors/ · engines/{identity,state,graph,intel,ml,anomaly,risk,iot}.py · static/ (web UI) ·
`eval/` fixed evaluation fixtures · `lab/` IoT lab · `scripts/` · `tests/` · `qa/` saved verification logs · `docs/`.
