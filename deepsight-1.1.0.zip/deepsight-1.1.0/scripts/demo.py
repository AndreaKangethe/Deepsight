#!/usr/bin/env python3
"""Start DEEPSIGHT and the isolated IoT lab, wait for readiness, import and scan."""
import getpass
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import urllib.error
import urllib.request


def main():
    root=Path(__file__).resolve().parents[1]
    env=dict(os.environ)
    env.setdefault('ASIVM_ADMIN_USER','admin')
    env['ASIVM_ADMIN_PASSWORD']=env.get('ASIVM_ADMIN_PASSWORD') or getpass.getpass('DEEPSIGHT administrator password (used for this demo): ')
    if not env['ASIVM_ADMIN_PASSWORD']:raise SystemExit('A password is required for the demo script')
    env.setdefault('ASIVM_SEED_DEMO','true')
    subprocess.run(['docker','compose','-f','docker-compose.yml','-f','docker-compose.lab.yml','up','--build','-d'],cwd=root,env=env,check=True)
    url=env.get('ASIVM_URL','http://localhost:'+env.get('ASIVM_PORT','8000'))
    for _ in range(180):
        try:
            with urllib.request.urlopen(url+'/api/health',timeout=3) as response:health=json.load(response)
            if health.get('status')=='ok' and health.get('demo',{}).get('state') not in ('running','error'):break
        except (urllib.error.URLError,TimeoutError):pass
        time.sleep(2)
    else:raise SystemExit('DEEPSIGHT did not become healthy; inspect docker compose logs app')
    subprocess.run([sys.executable,'lab/scan_lab.py','--url',url],cwd=root,env=env,check=True)
    print('DEEPSIGHT ready: '+url)

if __name__=='__main__':main()
