#!/usr/bin/env python3
"""Register the IoT lab in a running DEEPSIGHT and scan it. Standard library only; run from the project root.

  python lab/scan_lab.py  # reads ASIVM_ADMIN_USER / ASIVM_ADMIN_PASSWORD, or prompts securely

Steps: (1) import lab/lab_inventory.json (what a passive IoT-discovery tool would report: firmware, vendor, risky config),
(2) live TCP-connect scan of the four lab devices (only reachable from inside the compose network, which is why the
scan runs inside the app container), (3) print what was found. Safe to re-run (integrations are reused).
"""
import argparse
import getpass
import json
import os
import sys
import time
import urllib.error
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
TARGETS = {"172.28.50.10": "lab-camera-01", "172.28.50.11": "lab-telnet-01",
           "172.28.50.12": "lab-gateway-01", "172.28.50.13": "lab-mqtt-01"}
PORTS = [21, 22, 23, 80, 443, 554, 1883, 2323, 8080, 8291, 8883, 9100]
SCAN_NAME, INV_NAME = "iot-lab-scan", "iot-lab-inventory"


class Api:
    def __init__(self, base):
        self.base, self.token = base.rstrip("/"), None

    def call(self, method, path, body=None):
        req = urllib.request.Request(self.base + "/api" + path, method=method,
                                     data=json.dumps(body).encode() if body is not None else None)
        req.add_header("Content-Type", "application/json")
        if self.token:
            req.add_header("Authorization", "Bearer " + self.token)
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                return json.loads(r.read() or b"null")
        except urllib.error.HTTPError as e:
            sys.exit(f"{method} {path} -> HTTP {e.code}: {e.read().decode()[:300]}")
        except urllib.error.URLError as e:
            sys.exit(f"cannot reach {self.base}: {e.reason}. Is the stack up?")


def ensure(api, name, kind, config):
    for s in api.call("GET", "/integrations"):
        if s["name"] == name:
            return s["id"]
    return api.call("POST", "/integrations", {"name": name, "kind": kind, "config": config, "frequency_minutes": 0})["id"]


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--url", default=os.getenv("ASIVM_URL", "http://localhost:8000"))
    a = ap.parse_args()
    user = os.getenv("ASIVM_ADMIN_USER", "admin")
    password = os.getenv("ASIVM_ADMIN_PASSWORD") or getpass.getpass("DEEPSIGHT administrator password: ")
    api = Api(a.url)
    api.token = api.call("POST", "/auth/login", {"username": user, "password": password})["token"]

    inv_id = ensure(api, INV_NAME, "generic_json", {})
    content = open(os.path.join(HERE, "lab_inventory.json"), encoding="utf-8").read()
    run = api.call("POST", f"/integrations/{inv_id}/import", {"filename": "lab_inventory.json", "content": content})
    print(f"[1/3] inventory import: {run['status']} (received {run['received']}, processed {run['processed']}, failed {run['failed']})")

    scan_id = ensure(api, SCAN_NAME, "tcp_discovery", {
        "authorized": True, "targets": list(TARGETS), "ports": PORTS, "timeout": 2.0,
        "hostnames": TARGETS, "asset_type": "iot_device"})
    test = api.call("POST", f"/integrations/{scan_id}/test")
    if not test.get("ok"):
        sys.exit(f"scan config rejected: {test}")
    api.call("POST", f"/integrations/{scan_id}/collect")
    for _ in range(60):
        time.sleep(1)
        st = api.call("GET", f"/integrations/{scan_id}/status")
        if st["status"] not in ("running", "queued"):
            break
    runs = api.call("GET", f"/integrations/{scan_id}/runs")
    r = runs[0] if runs else {}
    print(f"[2/3] live scan of {len(TARGETS)} devices: {r.get('status')} (received {r.get('received')}, failed {r.get('failed')})"
          + (f" - {r.get('error')}" if r.get("error") else ""))

    print("[3/3] lab assets in DEEPSIGHT:")
    items = api.call("GET", "/assets?q=lab-&size=50")["items"]
    for x in sorted(items, key=lambda i: i["name"]):
        print(f"   {x['name']:<16} {x['type']:<11} {','.join(x['ips']):<14} findings={x['open_findings']} "
              f"risk={x['risk_level']}({x['risk_score']}) identity={x['identity_status']}")
    pend = api.call("GET", "/identity/decisions?status=pending")
    print(f"   pending identity decisions: {len(pend.get('items', []))}")
    print(f"\nOpen {a.url} -> Assets, filter type = iot_device (names start with lab-).")


if __name__ == "__main__":
    main()
